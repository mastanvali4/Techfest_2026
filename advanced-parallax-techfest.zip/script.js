
window.addEventListener('scroll',()=>{
document.querySelector('.stars').style.transform =
'translateY(' + window.scrollY*0.3 + 'px)';
});
