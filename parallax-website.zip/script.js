window.addEventListener('scroll',()=>{
let scroll=window.pageYOffset;
document.querySelector('.bg').style.transform=`translateY(${scroll*0.5}px)`;
});